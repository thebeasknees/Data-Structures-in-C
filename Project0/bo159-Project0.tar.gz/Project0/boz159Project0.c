#include <stdio.h>  //For input/output functions.
#include <stdlib.h> //For malloc, free, etc.
#include "Project0.h"  //Include our own header file for the Employee struct.


int main()
{
    FILE *file;
    char buffer[100];
    int counter = 0;
    int i = 0;
    
    printf("Opening %s...\n","Project0Input.txt");
    file = fopen("Project0Input.txt","r");
    if(fgets(buffer,100,file)== NULL)
    {
        printf("Error: Could not open file!");
        return;
    }
    printf("File opened successfully!\n");
    printf("%s",buffer);
    
    while(fgets(buffer,100,file) != NULL )     //uses while loop to traverse through file until end
    {
        counter++;
    }
    
    Employee *record = (Employee*)malloc(counter * sizeof(Employee));  //dynamic allocation
    if(record == NULL)
    {
        printf("Memory allocation failed!");
        return;
    }
    printf("Memory allocation successful!\n");
    
    rewind(file);   //ensures whole file is being read
    int temp;                   //create temp to store first line
    fscanf(file,"%i", &temp);   //scans first line to store first line and move to second line
    for(i=0;i<counter;i++)      //traversing the file to generate employee list
    {
        fscanf(file, "%s %d %lf", record[i].name, &record[i].identification, &record[i].rate);
        printf("%-10s %d %0.2lf\n", record[i].name, record[i].identification, record[i].rate);
    }
    fclose(file); //closing file after done with it
    free(record);  //free up memory to avoid any memory issues
    return 0;
}
    
    
    
	//1.  Open the file Project0.txt and read in the first line of the file to determine how many Employees we need for our array, and use malloc() to dynamically allocate an array of this size.
	
	
	//2.  Use a loop to read the Employee information from Project0.txt and write the information to the entries of your array.  Suggestion:  read a single line of the file using fgets() then use sscanf() to parse out the variables from the line.  
	
	
	//3.  Loop through your array and print out the employee information.  Each employee (name, ID, hourly rate) should be on a single line.  The name should be left justified in a column of width 10.  The IDs are each 6 digits long so they can be printed with a single space after it.  The hourly rate should be printed to 2 decimal places.
       
