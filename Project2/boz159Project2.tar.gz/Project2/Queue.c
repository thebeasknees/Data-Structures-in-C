#include "Queue.h"

/******
 * In this file, provide all of the definitions of the queue functions as described in Queue.h.
 *
 * ****/

Queue newQueue()
{
    QueueImp* queue = (QueueImp*)malloc(sizeof(QueueImp));
    queue->head = NULL;
    queue->foot = NULL;
    return queue;
}

NodeLL* allocateNode(Element value)
{
    NodeLL* newNode;
    newNode = (NodeLL*)malloc(sizeof(NodeLL));
    if(newNode == NULL)
        printf("Error:Unable to allocate NodeLL\n");
    newNode->element = value;
    newNode->next = NULL;
    return newNode;
}

void enqueue(Queue q, Element value)
{
    NodeLL* newNode = allocateNode(value);
    if(q->foot == NULL)
    {
        q->head = newNode;
        q->foot = newNode;
    }
    else
    {
        q->foot->next = newNode;
        q->foot = q->foot->next;
    }
}

int dequeue(Queue q, Element *e)
{
    if(q->head == NULL)
    {
        printf("Error:Queue is empty\n");
        return FALSE;
    }
    else if(q->head == q->foot)
    {
        *e = q->head->element;
        q->head = NULL;
        q->foot = NULL; 
        
    }
    else
    {
        NodeLL* newNode = q->head;
        q->head = q->head->next;
        *e = newNode->element;
        free(newNode);
    }
    return TRUE;
}

int frontElement(Queue q, Element *e)
{
    if(q->head == NULL)
    {
        printf("Error:Queue is empty\n");
        return FALSE;
    }
    else
    {
        e->shopperID = q->head->element.shopperID;
        e->numberOfItems = q->head->element.numberOfItems;
        return TRUE;
    }
}

int isEmpty(Queue q)
{
    if(q->head == NULL)
        return TRUE;
    else
        return FALSE;
}

void freeQueue(Queue q)
{
    freeNodeLL(q->head);
    free(q);
}

void freeNodeLL(NodeLL *p)
{
    if(p == NULL)
        return;
    freeNodeLL(p->next);
    free(p);
}
