#include "Queue.h"

int main()
{
    //declare all variables
    int i = 0;
    int time = 0;
    int pTime = 0;
    int timeDiff = 0;
    int shopperID;
    int numberOfItems;
    int shortestTimeLeft = 0;
    int shortestLine = 0;
    int waitTime = 0;
    int maxWaitTime = 0;
    int allQEmpty;
    Element shopper;
    Element e;
    
    //initialize number of queues
    int numOfQueues = 3;
    Queue* q = (Queue*)malloc(numOfQueues * sizeof(Queue));
    for(i = 0;i < numOfQueues;i++)
    {
        q[i] = newQueue();
    }
    
    //Open file
    FILE *f;
    f = fopen("p2Input.txt","r");
    
    if(f == NULL)
    {
        printf("Error:Unable to open file.\n");
        return -1;
    }
    
    while(fscanf(f, "%d %d %d", &time, &shopperID, &numberOfItems) != EOF)
    {
        allQEmpty = TRUE;
        for(i = 0;i < numOfQueues;i++)
        {
            if(!isEmpty(q[i]))
                allQEmpty = FALSE;
        }
        if(!allQEmpty)
        {
            for(i = 0; i < numOfQueues;i++)
            {
                timeDiff = time - pTime;
                if(!isEmpty(q[i]))
                {
                    if(!isEmpty(q[i]))
                    {
                        if(timeDiff < q[i]->head->element.numberOfItems)
                        {
                            q[i]->head->element.numberOfItems -= timeDiff;
                            timeDiff = 0;
                        }
                        else if(timeDiff >= q[i]->head->element.numberOfItems)
                        {
                            dequeue(q[i], &e);                             
                            timeDiff -= e.numberOfItems;
                            if(q[i]->head != NULL)
                                q[i]->head->element.numberOfItems -= timeDiff;
                            printf("Shopper %d finished checking out of Line %d at time %d\n", e.shopperID, i, pTime + e.numberOfItems);
                        }
                    }
                    else
                        timeDiff = 0;
                }
            }
        }
       
        //Determine shortest line for shoppers to be placed into
        int* timeLeft = (int*)malloc(numOfQueues * (sizeof(int)));
        pTime = time;
        for(i = 0;i < numOfQueues;i++)
        {
            if(isEmpty(q[i]))
                timeLeft[i] = 0;
            else
            {
                timeLeft[i] = 0;
                NodeLL* newNode = q[i]->head;
                while(newNode != NULL)
                {
                    timeLeft[i] += newNode->element.numberOfItems;
                    newNode = newNode->next;
                }
            }
        }
        shortestTimeLeft = timeLeft[0];
        shortestLine = 0;
        for(i = 0;i < numOfQueues;i++)
        {
            if(shortestTimeLeft > timeLeft[i])
            {
                shortestTimeLeft = timeLeft[i];
                shortestLine = i;
            }
        }
        
            
        //enqueue shoppers after shortest lines established 
        shopper.numberOfItems = numberOfItems;
        shopper.shopperID = shopperID;
        if(isEmpty(q[shortestLine]))
            shopper.numberOfItems--;
        enqueue(q[shortestLine],shopper);  
        
        //Determine max wait 
        maxWaitTime = 0;
        for(i = 0;i < numOfQueues;i++)
        {
            waitTime = 0;
            if(isEmpty(q[i]))
                waitTime = 0;
            else
            {
                NodeLL* newNode = q[i]->head;
                while(newNode != NULL)
                {
                    waitTime = waitTime + newNode->element.numberOfItems;
                    newNode = newNode->next;
                }
                
            }
            if(waitTime > maxWaitTime)
            {
                maxWaitTime = waitTime;
            }
        }
        free(timeLeft);
    }
    
    while(!allQEmpty)
    {
        time++;
        for(i = 0; i < numOfQueues;i++)
        {
            timeDiff = 1;
            if(!isEmpty(q[i]))
            {
                if(timeDiff < q[i]->head->element.numberOfItems)
                {
                    q[i]->head->element.numberOfItems -= timeDiff;
                }
                else if(timeDiff == q[i]->head->element.numberOfItems)
                {
                    dequeue(q[i], &e);
                    timeDiff -= e.numberOfItems;
                    if(q[i]->head != NULL)
                        q[i]->head->element.numberOfItems -= timeDiff;
                    printf("Shopper %d finished checking out of Line %d at time %d\n", e.shopperID, i, time);
                }
                else
                {

                }
            }
        }
        allQEmpty = TRUE;
        for(i = 0;i < numOfQueues;i++)
        {
            if(!isEmpty(q[i]))
                allQEmpty = FALSE;
        }
    }
    //close file and free queues
    fclose(f);
    for(i=0;i<numOfQueues;i++)
    {
        freeQueue(q[i]);
    }
    free(q);
    return 0;
}