#include "HashTable.h"

/******
 * In this file, provide all of the definitions of the hash table functions as described in HashTable.h.
 *
 * ****/

//Malloc a new HashTableImp, malloc the hashTable to be an array of HashTableEntrys of size n, 
//initialize each iChainIndex to be -2 (indicating that the spot is empty), 
//and return a pointer to the HashTableImp.
HashTable newHashTable(int n)
{
    HashTableImp* HashTable = (HashTableImp*)malloc(sizeof(HashTableImp));
    HashTable->n = n;
    HashTable->hashTable = (HashTableEntry*)malloc(n * sizeof(HashTableEntry));
    
    int i;
    for(i = 0;i < n;i++)
    {
        HashTable->hashTable[i].chainIndex = -2;
    }
    return HashTable;
}


//Free the HashTable h.
void freeHashTable(HashTable h)
{
    free(h->hashTable);
    free(h);
}


//Given a string, convert it into an integer to be used in either
//the division method or the midsquare method.
int stringToInt(char *stringToConvert)
{
    int sum = 0, i;
    
    for(i = 0;i < strlen(stringToConvert);i++)
    {
        sum += stringToConvert[i];
    }
    return sum;
}


//Given a key value, use the division method to find a 
//valid index for hashTable.
int divisionMethod(int key, int n)
{
    return (key % n);
}


//Given a key value, use the midsquare method to find a 
//valid index for hashTable.
int midsquareMethod(int key, int n)
{
    key = key * key;
    key = key / 1000;
    key = key % n;
    return key;
}


//Insert e into our HashTable h by using stringToInt to convert the team name
//into an integer and then passing that integer to one of the division or 
//midsquare method functions.  If this entry is not occupied, insert it there
//and change the corresponding iChainIndex to be -1.  If there is a collision,
//use open chaining to find an open location for e, and update the iChainIndex
//values accordingly.
void put(HashTable h, Element e)
{
    int index = midsquareMethod(stringToInt(e.teamName), h->n);
    if(h->hashTable[index].chainIndex == -2)
    {           
        h->hashTable[index].key = e;
        h->hashTable[index].chainIndex = -1;
    }
    else
    {
        int k = 7;
        int endOfChain = index;
        while(h->hashTable[endOfChain].chainIndex != -1)
        {
            endOfChain = h->hashTable[endOfChain].chainIndex;
        }
        int newIndex = (endOfChain + k) % h->n;
        while(h->hashTable[newIndex].chainIndex != -2)
        {
            newIndex = (newIndex + k) % h->n;
        }
        h->hashTable[endOfChain].chainIndex = newIndex;
        h->hashTable[newIndex].key = e;
        h->hashTable[newIndex].chainIndex = -1;
    }
}


//Return a pointer to the key struct containing the data that matches teamName
//if it exists. If it does not exist, return NULL.
Element* get(HashTable h, char *teamName)
{
    int intValue = stringToInt(teamName);
    int index = midsquareMethod(intValue, h->n);
    if(h->hashTable[index].chainIndex == -2)
    {
        return NULL;
    }
    else
    {
        while(strcmp(h->hashTable[index].key.teamName, teamName) != 0 && h->hashTable[index].chainIndex != -1)
        {
            index = h->hashTable[index].chainIndex;
        }
        if(strcmp(h->hashTable[index].key.teamName, teamName) == 0)
        {
            return &h->hashTable[index].key;
        }
        else
        {
            return NULL;
        }
    }
}
