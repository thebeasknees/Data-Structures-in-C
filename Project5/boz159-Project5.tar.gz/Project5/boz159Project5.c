#include "HashTable.h"


int main()
{
    //Declare variables
    int n = 100;
    char str[100], team1[50], team2[50], score1[5], score2[5];
    Element e;
    HashTable myHT = newHashTable(n);
    
    //Open nbaTeamNames.csv
    FILE* fIn;
    fIn = fopen("nbaTeamNames.csv", "r");
    if(fIn == NULL)
    {
        printf("Error:could not open file!");
        exit(1);
    }
    
    //Read into file
    while(fgets(str, 100, fIn))
    {
     //   printf("%s", str);
        if(str[strlen(str) - 1] == '\n')
        {
            str[strlen(str) - 2] = '\0';
        } 
        strcpy(e.teamName, str);
        e.wins = 0;
        e.losses = 0;
        put(myHT, e);
    }
    
    //close nbaTeamNames.csv
    fclose(fIn);
    
    //Open nbaData2019.csv
    fIn = fopen("nbaData2019.csv", "r");
    if(fIn == NULL)
    {
        printf("Error:could not open file!");
        exit(1);
    }
    
    //Scan nbaData2019.csv to determine wins/losses for teams
    while(fgets(str, 100, fIn))
    {
        sscanf(str, "%[^,],%[^,],%[^,],%[^,\n]", team1, score1, team2, score2);
        Element* t1 = get(myHT, team1);
        Element* t2 = get(myHT, team2);
        if(atoi(score1) > atoi(score2))
        {
            if(t1)
            {
                t1->wins++;
            }
            else
            {
                printf("Team not found.");
            }
            if(t2)
            {
                t2->losses++;
            }
            else
            {
                printf("Team not found.");
            }
        }
        if(atoi(score2) > atoi(score1))
        {
            if(t2)
            {
                t1->losses++;
            }
            else
            {
                printf("Team not found.");
            }
            if(t1)
            {
                t2->wins++;
            }
            else
            {
                printf("Team not found");
            }
        }
    }
    
    //Close nbaData2019.csv
    fclose(fIn);
    
    //Re-open nbaTeamNames.csv to print results
    fIn = fopen("nbaTeamNames.csv", "r");
    if(fIn == NULL)
    {
        printf("Error:could not open file!");
        exit(1);
    }
    
    //Scan nbaTeamNames.csv and print out win/loss record for all teams
    while(fgets(str, 100, fIn))
    {
        sscanf(str, "%[^\r\n]", team1);
        Element* results = get(myHT, team1);
        if(results)
        {
            printf("%s:%d Wins - %d Losses\n", results->teamName, results->wins, results->losses);
        }
        else
        {
            printf("team not found\n");
        }
    }
    
    //Close nbaTeamNames.csv and free Hash Table
    fclose(fIn);
    freeHashTable(myHT);
    return 0;
}


