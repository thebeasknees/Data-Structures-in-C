#include "Stack.h"

/******
 * In this file, provide all of the definitions of the stack functions as described in stack.h.
 *
 * ****/

Stack newStack(int maximumStackSize)
{
    StackImp* stack = (StackImp*)malloc(sizeof(StackImp));
    stack->stackElements = (Element*)malloc(sizeof(Element) * maximumStackSize);
    stack->count = 0;
    stack->maxSize = maximumStackSize;
    return stack;
}

int isOperator(char x)
{
    if(x == '+' || x == '-' || x == '*' || x == '/')
        return 1;
    else
        return 0;
}

int pre(char x)
{
    if(x == '+' || x == '-')
        return 1;
    else if(x == '*' || x == '/')
        return 2;
    else
        return 0;
}

void push(Stack s, Element e)
{
    if(s->count == s->maxSize-1)
    {
        printf("Error:Stack is full!\n");
    }
    else
    {
        s->stackElements[s->count] = e;
        s->count++;
    }
}

Element pop(Stack s)
{
    if(isEmptyStack(s) == 1)
    {
        printf("Error:Stack is empty!\n");
    }
    else
    {
        s->count--;
        return s->stackElements[s->count];
    }
}

int isEmptyStack(Stack s)
{
    if(s->count == 0)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

Element topElement(Stack s)
{
    if(isEmptyStack(s))
    {
        printf("Error:Stack is empty!");
    }
    else
    {
        return s->stackElements[s->count-1];
    }
}

void freeStack(Stack s)
{
    while(isEmptyStack(s) == 0)
    {
        pop(s);
    }
}