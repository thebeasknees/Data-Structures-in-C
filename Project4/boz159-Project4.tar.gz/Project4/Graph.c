#include "Graph.h"

/******
 * In this file, provide all of the definitions of the graph functions as described in Graph.h.
 *
 * ****/

//Given the number of vertices of the graph, malloc the nxn adjacency matrix and initialize every edge to 0 (i.e. the edges aren't there initially).
//Return the address of the graph.
Graph newGraph(int n)
{
    int i, j;
    GraphImp* Graph = (GraphImp*)malloc(sizeof(GraphImp));
    Graph->n = n;
    Graph->adjacencyM = (int**)malloc(n * sizeof(int*));
    
    for(i = 0;i < n;i++)
    {
        Graph->adjacencyM[i] = (int*)calloc(n, sizeof(int));  
    }  
    return Graph;
}

//Free the adjacency matrix and then the graph itself.
void freeGraph(Graph g)
{
    int i;
    for(i = 0;i < g->n;i++)
    {
        free(g->adjacencyM[i]);
    }
    free(g->adjacencyM);
    free(g);
}

//Add the edge e to the graph g.
void addEdge(Graph g, Edge e)
{
    g->adjacencyM[e.fromVertex][e.toVertex] = 1;
}

//Given graph g and vertex v, scan the adjacency matrix and return the first edge in g such that v is the "fromVertex" of the edge.
//Return NULL if there is no such edge.
Edge firstAdjacent(Graph g, Vertex v)
{
    int i;
    for(i = 0;i < g->n;i++)
    {
        if(g->adjacencyM[v][i])
        {
            //return Edge(v,i)
            Edge e;
            e.fromVertex = v;
            e.toVertex = i;
            return e;
        }
    }
    Edge e;
    e.fromVertex = e.toVertex = -1;
    return e;
}

//Given graph g and vertex e, scan the adjacency matrix and return the next edge after e in g such that e.fromVertex is the "fromVertex" of the edge.
//Return NULL if there is no such edge.
Edge nextAdjacent(Graph g, Edge e)
{
    int i;
    for(i = e.toVertex + 1;i < g->n;i++)
    {
        if(g->adjacencyM[e.fromVertex][i])
        {
            Edge newV;
            newV.fromVertex = e.fromVertex;
            newV.toVertex = i;
            return newV;
        }
    }
    Edge newV;
    newV.fromVertex = newV.toVertex = -1;
    return newV;
}

//Print the sequence of vertices on a shortest path in g starting from start and ending at destination.  
//A shortest path should be computed using the Breadth First Search (BFS) algorithm that maintains the parents of each vertex in the shortest path tree as defined in class.  
//BFS can be implemented directly in this function, or you may create a new function for BFS.
void shortestPath(Graph g, Vertex start, Vertex destination)
{
    int i;
    int* visited = (int*)malloc(sizeof(int) * g->n);
    for(i = 0;i < g->n;i++)
    {
        visited[i] = FALSE;
    }
    int* parent = (int*)malloc(sizeof(int) * g->n);
    for(i = 0;i < g->n;i++)
    {
        parent[i] = -1;
    }
    
    Edge e;
    Vertex tempV, curV;
    Stack s = newStack(g->n);
    Queue q = newQueue();
    enqueue(q, start);
    visited[start] = TRUE;
    curV = start;
    while(dequeue(q, &curV))
    {
        for(e = firstAdjacent(g, curV);e.toVertex != -1;e = nextAdjacent(g,e))
        {
            tempV = e.toVertex;
            if(visited[tempV] == FALSE)
            {
                enqueue(q,tempV);
                visited[tempV] = TRUE;
                parent[tempV] = curV;  
            }
        }
    }
    
    curV = FALSE;
    for(i = 0;i < g->n;i++)
    {
        if(parent[i] != -1)
        {
            curV = TRUE;
        }
    }
    
    if(parent[destination] == -1)
    {
        printf("There is no path from %d to %d.\n", start, destination);
    }
    else
    {
        curV = destination;
        while(curV != -1)
        {
            push(s, curV);
            curV = parent[curV];
        }
        printf("Shortest path from %d to %d:", start, destination);
        while(!isEmptyStack(s))
        {
           int nextV = pop(s);
           printf(" %d ", nextV);
           if(!isEmptyStack(s))
               printf("->");
        }
        printf("\n");
    }
    freeStack(s);
    free(parent);
    free(visited);
    freeQueue(q);
}