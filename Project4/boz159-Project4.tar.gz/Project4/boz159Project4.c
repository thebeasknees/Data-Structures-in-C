#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "Graph.h"
#include "Queue.h"
#include "Stack.h"

int main()
{
    char str[100];
    FILE* fIn;
    
    fIn = fopen("p4Input.txt", "r");
    if(fIn == NULL)
    {
        printf("Error:Unable to open...");
        exit(1);
    }

    fscanf(fIn, "%s", str);
    int numVertices = atoi(str);
    
    fscanf(fIn, "%s", str);
    int numEdges = atoi(str);
    
    int i;
    int fromVertex, toVertex;
    Graph g;
    g = newGraph(numVertices);
    while(fgets(str, 100, fIn) && i < numEdges)
    {
        fscanf(fIn, "%d %d", &fromVertex, &toVertex);
        Edge e;
        e.fromVertex = fromVertex;
        e.toVertex = toVertex;
        
        addEdge(g, e);
        i++;
    }
    
    i = 0;
    fscanf(fIn, "%s\n", str);
    int numPaths = atoi(str);
    
    while(fgets(str, 100, fIn) && i < numPaths)
    {
        int pathStart, pathEnd;
        char blankSpace[20];
        sscanf(str, "%s %d %d", blankSpace, &pathStart, &pathEnd);
        shortestPath(g, pathStart, pathEnd);
        i++;
    }
    freeGraph(g);
    fclose(fIn);
    return 0;
}


