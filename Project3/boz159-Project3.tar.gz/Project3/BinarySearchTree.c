#include "BinarySearchTree.h"

/******
 * In this file, provide all of the definitions of the queue functions as described in BinarySearchTree.h.
 *
 * ****/

//Malloc a new BinarySearchTreeImp and return it's address.
BinarySearchTree newBinarySearchTree()
{
    BinarySearchTreeImp* BinarySearchTree = (BinarySearchTreeImp*)malloc(sizeof(BinarySearchTreeImp));
    BinarySearchTree->root = NULL;
    return BinarySearchTree;          
}

//Free the BinarySearchTree and any nodes that still exist in the tree.
void freeBinarySearchTree(BinarySearchTree tree)
{
    freeBSTNode(tree->root);
    free(tree);
}

//Free the BST left and right nodes.
void freeBSTNode(NodeT* p)
{
    if(p == NULL)
        return;
    freeBSTNode(p->left);
    freeBSTNode(p->right);
    free(p);
}

//Allocate a new node and store "value" as the Element in the node.  Return the address of the node.
NodeT *allocateNode(Element value)
{
    NodeT* node = (NodeT*)malloc(sizeof(NodeT));
    node->element = value;
    node->left = NULL;
    node->right = NULL;
    return node;
}

//Recursive algorithm for searching for a node with key value equal to searchValue.  Return a pointer to the node if you find it or return NULL if it does not exist.
NodeT *search(NodeT *p, int searchValue)
{
    if(p == NULL)
	return NULL;  
    if(searchValue == p->element.accountNumber)
	return p;
    if(searchValue < p->element.accountNumber)
	return search(p->left, searchValue);
    else
	return search(p->right, searchValue);  
}

//Create a node to store the given Element and add it as a leaf in the BinarySearchTree.  Do not worry about balancing the tree for this project.
//Return true if the insert worked successfully, and return false if the node already existed in the tree.
int insert(NodeT **pp, Element value)
{
    if((*pp) == NULL)
    {
        (*pp) = allocateNode(value);
        return TRUE;
    }   
    if(value.accountNumber == (*pp)->element.accountNumber)
        return FALSE;
    if(value.accountNumber < (*pp)->element.accountNumber)
        return insert(&((*pp)->left), value);
    else
        return insert(&((*pp)->right), value);
}

//Recursively print the key values of all nodes in the subtree rooted at p in increasing order.
void printInOrder(NodeT *p)
{
    if(p == NULL)
        return;
    printInOrder(p->left);
    printf("%d %.2lf\n", p->element.accountNumber, p->element.accountBalance);
    printInOrder(p->right);
}

//Recursively print the key values of all nodes in the subtree rooted at p according to a preorder traversal.
void printPreOrder(NodeT *p)
{
    if(p == NULL)
        return;
    printf("%d %.2lf\n", p->element.accountNumber, p->element.accountBalance);
    printPreOrder(p->left);
    printPreOrder(p->right);
}