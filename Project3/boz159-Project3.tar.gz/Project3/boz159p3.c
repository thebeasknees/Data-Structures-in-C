#include "BinarySearchTree.h"


int main()
{
    //Declare variables
    int i;
    int accountNumber;
    double accountBalance;
    char str[100];
    char type[7];
    char printType[9];
    BinarySearchTree tree = newBinarySearchTree();
    
    //Open file
    FILE* f;
    f = fopen("largeInput.txt", "r");
    if(f == NULL)
    {
        printf("Error:Unable to open file!\n");
        exit(1);
    }
    
    //Read first word of line
    while(fgets(str, 100, f) != NULL)
    {
        for(i = 0;i < 7;i++)
        {
            if(str[i] != ' ')
            {
                type[i] = str[i];
            }
            else
            {
                type[i] = '\0';
                break;
            }
        }
        
        //Test for each first word case (CREATE/SALE/PRINT)
        if(strcmp(type, "CREATE") == 0)
        {
            sscanf(str, "%s %d", type, &accountNumber);
            Element e;
            e.accountNumber = accountNumber;
            e.accountBalance = 0;
            if(!insert(&(tree->root), e))
                printf("Error:Invalid insert");
        }
        else if(strcmp(type, "SALE") == 0)
        {
            sscanf(str, "%s %d %lf", type, &accountNumber, &accountBalance);
            Element e;
            e.accountNumber = accountNumber;
            e.accountBalance = 0;
            NodeT* n;
            n = search(tree->root, accountNumber);
            n->element.accountBalance += accountBalance;
        }
        else if(strcmp(type, "PRINT") == 0)
        {
            sscanf(str, "%s %s", type, printType);
            if(strcmp(printType, "INORDER") == 0)
                printInOrder(tree->root);
            else if(strcmp(printType, "PREORDER") == 0)
                printPreOrder(tree->root);
        }
        else
        {
            printf("Error:Unknown input.\n");
        }
    }
    //free BST and close the file
    free(tree);
    tree->root = NULL;
    fclose(f);
    return 0;
}